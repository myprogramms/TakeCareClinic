package com.capgemini.tcc.bean;

import java.util.Date;

public class PatientBean {
	private int patientId;
	private String patientName;
	private int age;
	private long phoneNumber;
	private String description;
	private Date consultationDate;

	public PatientBean() {

	}

	public PatientBean(int patientId, String patientName, int age,
			long phoneNumber, String description, Date consultationDate) {
		super();
		this.patientId = patientId;
		this.patientName = patientName;
		this.age = age;
		this.phoneNumber = phoneNumber;
		this.description = description;
		this.consultationDate = consultationDate;
	}

	public PatientBean(String patientName, int age, long phoneNumber,
			String description, Date consultationDate) {
		super();
		this.patientName = patientName;
		this.age = age;
		this.phoneNumber = phoneNumber;
		this.description = description;
		this.consultationDate = consultationDate;
	}

	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getConsultationDate() {
		return consultationDate;
	}

	public void setConsultationDate(Date consultationDate) {
		this.consultationDate = consultationDate;
	}
public String toString() {
	return "Name of the Patient: "+this.patientName+
			"\nAge: "+this.age+
			"\nPhone Number: "+this.phoneNumber+
			"\nDescription: "+this.description+
			"\nConsultation Date: "+this.consultationDate;
}
}