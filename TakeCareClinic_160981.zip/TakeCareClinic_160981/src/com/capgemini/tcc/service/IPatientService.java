package com.capgemini.tcc.service;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exceptions.ClinicException;

public interface IPatientService {
	int addPatientDetails(PatientBean patient) throws ClinicException;

	PatientBean getPatientDetails(int patientId) throws ClinicException;

	boolean validateDetails(PatientBean patient) throws ClinicException;

}
