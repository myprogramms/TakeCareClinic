package com.capgemini.contactbook.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exceptions.ContactBookException;
import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookServiceImpl implements ContactBookService {
	
	ContactBookDao dao = new ContactBookDaoImpl();
	// ------------------------------------------------------------------------------------------------
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		// TODO Auto-generated method stub
		return dao.addEnquiry(enqry);
	}

	// ------------------------------------------------------------------------------------------------
	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws ContactBookException {
		// TODO Auto-generated method stub
		return dao.getEnquiryDetails(EnquiryID);
	}

	// ------------------------------------------------------------------------------------------------
	@Override
	public boolean isValidEnquiry(EnquiryBean enqry)
			throws ContactBookException {
		List<String> list = new ArrayList<>();
		boolean result = false;

		if (!isValidFirstName(enqry.getfName())) {
			list.add("First Name should start with a Capital-letter");
		}
		if (!isValidLastName(enqry.getlName())) {
			list.add("Last Name should start with a Capital-letter");
		}
		if (!isValidContactNo(enqry.getContactNo())) {
			list.add("The Phone number should be exactly 10 digits");
		}
		if (!ValidatePDomain(enqry.getfName())) {
			list.add("First Name should start with a Capital-letter");
		}
		if (!ValidatePLocation(enqry.getfName())) {
			list.add("First Name should start with a Capital-letter");
		}

		if (!list.isEmpty()) {
			result = false;
			throw new ContactBookException(list + "");
		} else {
			result = true;
		}
		return result;
	}

	public boolean isValidFirstName(String fName) {

		String fNameRegEx = "[A-Z]{1}[a-zA-Z]{2,}";
		Pattern pattern = Pattern.compile(fNameRegEx);
		Matcher matcher = pattern.matcher(fName);
		return matcher.matches();
	}

	public boolean isValidLastName(String lName) {

		String lNameRegEx = "[A-Z]{1}[a-zA-Z]{2,}";
		Pattern pattern = Pattern.compile(lNameRegEx);
		Matcher matcher = pattern.matcher(lName);
		return matcher.matches();
	}

	public boolean isValidContactNo(String contactNo) {

		String contactNoRegEx = "[6-9]{1}[0-9]{9}";
		Pattern pattern = Pattern.compile(contactNoRegEx);
		Matcher matcher = pattern.matcher(contactNo);
		return matcher.matches();
	}

	public boolean ValidatePDomain(String domain) {

		String pDomainRegEx = "[A-Za-z]{1}[A-Za-z0-9]{1,}";
		Pattern pattern = Pattern.compile(pDomainRegEx);
		Matcher matcher = pattern.matcher(domain);
		return matcher.matches();
	}

	public boolean ValidatePLocation(String location) {

		String pLocationRegEx = "[A-Za-z]{1,}";
		Pattern pattern = Pattern.compile(pLocationRegEx);
		Matcher matcher = pattern.matcher(location);
		return matcher.matches();
	}
}
